Watson Advisory Services site package

Included:
- Core site files:
  index.html
  tax-services.html
  analytics-consulting.html
  financial-modeling.html
  bookkeeping.html
  quote.html
  thanks.html
  styles.css
  script.js
  robots.txt
  sitemap.xml
  logo.jpg
  headshot.jpg

Also included in /optional-review-admin/:
- admin.html
- admin-list.js
- approve.js
- featured.js
- d1-schema.sql

Notes:
- The core site will run without the optional review/admin files.
- If you want the site simplified, you can ignore the /optional-review-admin folder.
- Replace logo.jpg and headshot.jpg with your preferred final versions if needed.
